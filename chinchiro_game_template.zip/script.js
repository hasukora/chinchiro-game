let money = 1000;

function playGame() {
  const betInput = document.getElementById("bet");
  const bet = parseInt(betInput.value);

  if (!bet || bet <= 0) {
    alert("掛け金を入力してください");
    return;
  }

  if (bet > money) {
    alert("所持金が足りません！");
    return;
  }

  // サイコロを振る
  const dice = Array.from({ length: 3 }, () => Math.floor(Math.random() * 6) + 1);
  document.getElementById("die1").textContent = dice[0];
  document.getElementById("die2").textContent = dice[1];
  document.getElementById("die3").textContent = dice[2];

  const result = evaluateDice(dice);
  const resultText = document.getElementById("result");

  if (result === "win") {
    money += bet;
    resultText.textContent = `勝ち！+${bet}円`;
  } else if (result === "lose") {
    money -= bet;
    resultText.textContent = `負け！-${bet}円`;
  } else {
    resultText.textContent = "役無し！振り直し！";
  }

  document.getElementById("money").textContent = money;

  if (money <= 0) {
    alert("所持金がなくなりました。リロードで再開できます。");
  }
}

function evaluateDice(dice) {
  dice.sort((a, b) => a - b);
  const [a, b, c] = dice;

  if (a === b && b === c) {
    if (a === 1) return "win"; // ピンゾロ
    return "win";              // ゾロ目
  }

  if (a === 1 && b === 2 && c === 3) return "lose";  // ヒフミ
  if (a === 4 && b === 5 && c === 6) return "win";   // シゴロ

  if (a === b || a === c || b === c) return "point";

  return "none";
}
